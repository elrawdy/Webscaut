from flask import Flask, request, render_template_string

app = Flask(__name__)

documents = [
    {"title": "Wasser", "content": "Wasser ist eine chemische Verbindung aus Wasserstoff und Sauerstoff."},
    {"title": "Feuer", "content": "Feuer ist eine sichtbare Erscheinung einer Verbrennung."},
    {"title": "Erde", "content": "Die Erde ist der dritte Planet von der Sonne."},
    {"title": "Wind", "content": "Wind entsteht durch Druckunterschiede in der Atmosphäre."},
    {"title": "Technik", "content": "Technik ist die Anwendung wissenschaftlicher Erkenntnisse zur Lösung praktischer Probleme."},
    {"title": "Geschichte", "content": "Geschichte ist die Wissenschaft von der Vergangenheit der Menschheit."},
    {"title": "Biologie", "content": "Biologie ist die Lehre vom Leben."},
    {"title": "Physik", "content": "Physik ist eine Naturwissenschaft, die sich mit Materie und Energie befasst."},
    {"title": "Chemie", "content": "Chemie ist die Wissenschaft von den Stoffen und ihren Veränderungen."},
    {"title": "Mathematik", "content": "Mathematik ist die Wissenschaft von den Zahlen, Formen und Strukturen."}
]

TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Webscaut</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .result { margin-bottom: 20px; }
        .highlight { background-color: yellow; }
    </style>
</head>
<body>
    <h1>Webscaut</h1>
    <form method=\"GET\">
        <input type=\"text\" name=\"q\" placeholder=\"Suchbegriff\" value=\"{{ query }}\" required>
        <button type=\"submit\">Suchen</button>
    </form>
    {% if results %}
        <h2>Suchergebnisse für \"{{ query }}\":</h2>
        {% for doc in results %}
            <div class=\"result\">
                <h3>{{ doc.title }}</h3>
                <p>{{ doc.content|safe }}</p>
            </div>
        {% endfor %}
    {% elif query %}
        <p>Keine Ergebnisse gefunden.</p>
    {% endif %}
</body>
</html>
"""

@app.route("/", methods=["GET"])
def search():
    query = request.args.get("q", "").lower()
    results = []
    if query:
        for doc in documents:
            if query in doc["content"].lower():
                highlighted = doc["content"].replace(query, f'<span class="highlight">{query}</span>')
                results.append({"title": doc["title"], "content": highlighted})
    return render_template_string(TEMPLATE, results=results, query=query)

if __name__ == "__main__":
    app.run(debug=True)